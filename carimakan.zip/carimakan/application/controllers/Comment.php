<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Comment extends CI_Controller
{
    public function index()
    {
        $this->load->helper('url');
        $this->load->view('comment');
    }
    public function create()
    {
        $this->load->helper('url');
        $this->load->view('comment');
    }
    public function addComment()
    {
        $this->load->model("blog_model");

        //$data["posts"] = $this->blog_model->getID($id);
        $username = $this->session->userdata('username');
        $komentar = $this->input->post('komentar');
        $this->comment_model->insert_comment($username, $komentar);
        $this->load->view('comment', $data);
        redirect(base_url(), 'refresh');
    }
}
