<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Home";
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        if ($data['user']) {
            $this->isLogin($data);
        } else {
            $this->load->view('header', $data);
            $this->load->view('home');
            $this->load->view('footer');
        }
    }
    public function isLogin($data)
    {
        if (!$this->session->userdata('username')) {
            redirect('home');
        } else {
            $this->load->view('header_login', $data);
            $this->load->view('home');
            $this->load->view('footer');
        }
    }
    public function recent_post()
    { }
}
