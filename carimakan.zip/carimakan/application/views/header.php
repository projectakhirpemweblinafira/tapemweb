<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title; ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?= base_url('assets/'); ?>css/styles.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="header">
        <nav class="navbar navbar-custom">
            <div class="container-fluid">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?= base_url('auth/signup') ?>" style="color:white"><span class="glyphicon glyphicon-user"></span> Daftar</a></li>
                    <li><a href="<?= base_url('auth') ?>" style="color:white"><span class="glyphicon glyphicon-log-in"></span> Masuk</a></li>
                    <li><a href="<?= base_url('auth') ?>" style="color:white"><span class="glyphicon glyphicon-plus"></span> Buat Post</a></li>
                </ul>
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?= base_url('Home'); ?>" style="color:white">CariMakan.com</a>
                    <form class="navbar-form navbar-left" action="Sebelum Login/search/index.html" role="search" id="navBarSearchForm">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Cari">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <a href="Sebelum Login/search/index.html"><i class="glyphicon glyphicon-search"></i></a>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </nav>
    </div>