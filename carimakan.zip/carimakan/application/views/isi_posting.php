<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link href="styles.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
	<div class="row">
		<div class="main">
			<div class="col-lg-10">
				<?php foreach ($posts as $post) : ?>
					<h1 class='mt-4' style='color: #822F2F'><b><?php echo $post->nama_restoran; ?></b></h1>
					<p class='lead'>by <?php echo $post->username_posting; ?></p>
					<div class='keterangan' style='font-size:10pt;'>
						<p>Alamat : <?php echo $post->alamat; ?></p>
						<p>Jam Buka: <?php echo $post->hari_buka, ' - ', $post->hari_tutup, ', ',
											$post->jam_buka,
											' - ',
											$post->jam_tutup; ?></p>
						<p>Kontak : <?php echo $post->kontak; ?> </p>
					</div>
					<hr>
					<p>Posted on <?php echo $post->waktu_posting; ?></p>
					<p>Rating : 3/5</p><span class='fa fa-star checked'></span><span class='fa fa-star checked'></span>
					<span class='fa fa-star checked'></span><span class='fa fa-star'></span><span class='fa fa-star'></span>
					<hr>
					<img src="<?php echo base_url('assets/upload/' . $post->foto); ?>" width='500' />
					<hr>
					<p><?php echo $post->deskripsi; ?></p>
					<hr>
				<?php endforeach; ?>