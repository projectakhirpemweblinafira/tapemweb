<div class="zimagery" style="background-image:url(<?= base_url('assets/'); ?>images/bakground.jpg);; background-size: cover; width: 100%;">
    <div class="zimagery-overlay">
        <div class="search">
            <div class="logodanfind">
                <img src="<?= base_url('assets/'); ?>images/logo.png" alt="logo" class="logo" />
                <h1 class="tulisanfind">
                    Laper? Bingung mau cari makan dimana? Di Carimakan.com aja!
                </h1>
            </div>
            <div class="wrapper" align="center">
                <form action="Sebelum Login/search/index.html">
                    <select class="custom-select">
                        <option value="No">Select Category: </option>
                        <option value="Batu">Batu</option>
                        <option value="Kota">Kota Malang</option>
                        <option value="Kabupaten">Kab. Malang</option>
                    </select>
                    <input type="text" class="form-control" placeholder="Search for...">
                </form>
            </div>
        </div>
    </div>
</div>
<div class="w3-white w3-xlarge" style="max-width:1200px;margin:auto">
    <div class="main">
        <div class="isi">
            <div class="photorekom">
                <h4 align="center"> REKOMENDASI TEMPAT TERPOPULER HARI INI</h4>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="carousel slide multi-item-carousel" id="theCarousel">
                        <div class="carousel-inner" align="center">
                            <div class="item active">
                                <div class="col-xs-4"><a href="Sebelum Login/Isi Posting/Bagoepa.html"><img src="<?= base_url('assets/'); ?>Foto Makanan/Bagoepa.jpg" width="250" class="img-responsive"></a>
                                    <div class="content">
                                        <p>Bagoepa Malang</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-4"><a href="Sebelum Login/Isi Posting/Aventree.html"><img src="<?= base_url('assets/'); ?>Foto Makanan/Aventree.jpg" width="250" class="img-responsive"></a>
                                    <div class="content">
                                        <p>Aventree</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-4"><a href="Sebelum Login/Isi Posting/MadamWang.html"><img src="<?= base_url('assets/'); ?>Foto Makanan/MadamWang.jpg" width="250" class="img-responsive"></a>
                                    <div class="content">
                                        <p>Madam Wang</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="left carousel-control" href="#theCarousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                        <a class="right carousel-control" href="#theCarousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="recentpost">

                <div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">
                    <h4 align="center">RECENT POST</h4>
                    <!-- First Photo Grid-->
                    <div class="w3-row-padding w3-padding-16 w3-center" id="food">
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/AliceTeaRoom.jpg" alt="alice-tea-room" style="width:100%">
                            <h5><strong>Alice Tea Room</strong></h5>
                            <p style="font-size: 10pt;">Konsep vintage kini banyak digunakan oleh banyak cafe di banyak tempat. Alice Tea Room Malang adalah salah satunya....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/Alice Tea Room.html">Read More</a>
                        </div>
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/Kimchi Story.jpg" alt="Kimchi Story" style="width:100%">
                            <h5><b>Kimchi Story</b></h5>
                            <p style="font-size: 10pt;">Pesona Hallyu seolah tak pudar di kota Malang. Ini dibuktikan dengan munculnya berbagai kedai yang khusus menyajikan menu khas Korea....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/Kimchi Story.html">Read More</a>
                        </div>
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/Panties Pizza.jpg" alt="panties" style="width:100%">
                            <h5><strong>Panties Pizza</strong></h5>
                            <p style="font-size: 10pt;">Panties Pizza Malang adalah tempat makan pizza bergaya calzone di Malang. Kamu tahu calzone kan, Snackers?....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/Panties.html">Read More</a>
                        </div>
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/moshimoshi.jpg" alt="Moshi moshi" style="width:100%">
                            <h5><b>Moshi Moshi Ramen</b></h5>
                            <p style="font-size: 10pt;">Moshi Moshi Ramen merupakan lokasi kuliner yang menyajikan varian ramen sebagai sajian utamanya. Terdapat beberapa varian....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/Moshi Moshi.html">Read More</a>
                        </div>
                    </div>

                    <!-- Second Photo Grid-->
                    <div class="w3-row-padding w3-padding-16 w3-center">
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/Platter.jpg" alt="Popsicle" style="width:100%">
                            <h5><b>Platter</b></h5>
                            <p style="font-size: 10pt;">Platter merupakan tempat kuliner yang telah tersebar di beberapa kota di Indonesia, menu utamanya adalah nasi yang penyaji....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/platter.html">Read More</a>
                        </div>
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/mie setan.jpg" alt="Kober Mie Setan Suhat" style="width:100%">
                            <h5><b>Kober Mie Setan Suhat</b></h5>
                            <p style="font-size: 10pt;">Kober Mie Setan merupakan restoran yang terletak di Jl. Simpang Sukarno Hatta (seberang polinema). Menyuguhkan mie dengan....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/Mie Setan.html">Read More</a>
                        </div>
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/uniccrab.jpg" alt="Uniccrab" style="width:100%">
                            <h5><b>Uniccrab</b></h5>
                            <p style="font-size: 10pt;">Hello guys... sepulang dari Malang Night Paradise kami laper nih...saat itu kami juga merencanakanjauh-jauh hari setelah....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/uniccrab.html">Read More</a>
                        </div>
                        <div class="w3-quarter">
                            <img src="<?= base_url('assets/'); ?>Foto Makanan/waroengbamboe.jpg" alt="warung bambu" style="width:100%">
                            <h5><b>Waroeng Bamboe</b></h5>
                            <p style="font-size: 10pt;">Membahas wisata kuliner di Malang memang tak pernah ada habisnya, kota yang satu ini memang sangat kaya akan ragam wisata ....</p>
                            <a class="btn btn-primary" href="Sebelum Login/Isi Posting/waroengbamboe.html">Read More</a>
                        </div>
                    </div>

                    <!-- Pagination -->
                    <div class="w3-center w3-padding-30">
                        <div class="w3-bar">
                            <a href="index-1.html" class="fa fa-toggle-left" style="font-size:32px;"></a>
                            <a href="index-2.html" class="fa fa-toggle-right" style="font-size:32px;"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>