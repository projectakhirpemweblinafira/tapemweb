<!doctype html>
<html>

<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= $title; ?></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link href="styles.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
	<div class="Main-menu">
		<div class="container">
			<h1 style="font-size: 45pt" align="center"><strong>My Post</strong></h1><br><br>
			<hr>
			<?= $this->session->flashdata('message'); ?>
		</div>
		<div class="row">
			<?php if (count($posts) == 0) { ?>
				<h5>&emsp;No posts.</h5>
				<a class="btn btn-primary" href="<?php echo base_url('blog/create/'); ?>">Tambah Post</a>
			<?php } else {
			foreach ($posts as $post) { ?>
					<div class='col-md-4' align='center'>
						<a href='<?php echo base_url('blog/isiPosting/' . $post->id_post); ?>'>
							<img src="<?php echo base_url('assets/upload/' . $post->foto); ?>" width='250' class='img-fluid rounded mb-3 mb-md-0 img-responsive'>
						</a>
					</div>
					<div class='col-md-8'>
						<h3 style='color: #822F2F'><strong><?php echo $post->nama_restoran; ?></strong></h3>
						<div class='rating'>
							<span class='fa fa-eye'> 700 views </span>
							<span class='fa fa-star'> 270 rates</span>
							<span class='fa fa-comment'> 600 comments</span>
						</div>
						<br>
						<p style='font-size: 9pt'>Lokasi : <?php echo $post->alamat; ?></p>
						<p><?php echo $post->deskripsi; ?></p>
						<a class="btn btn-primary" href="<?php echo site_url('blog/edit/' . $post->id_post); ?>">Edit Post</a>
						<a class="btn btn-danger" href="<?php echo site_url('blog/delete/' . $post->id_post); ?>">Delete</a>
						<div class='date'><br>
							<p>Posted on:<?php echo $post->waktu_posting; ?></p>
						</div>
						<p>Edited on: -</p>
					</div>
				<?php }
		} ?>
		</div>
	</div>
</body>

</html>