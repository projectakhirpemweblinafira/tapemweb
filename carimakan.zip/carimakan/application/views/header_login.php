<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title; ?></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?= base_url('assets/'); ?>css/styles.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <div class="header">
        <nav class="navbar navbar-custom">
            <div class="container-fluid">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white">
                            <span class="glyphicon glyphicon-user"></span>
                            <?= $this->session->userdata('full_name');
                            ?><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?= base_url('blog/my_post'); ?>">Postingan Saya</a></li>
                            <li><a href="<?= base_url('user/edit'); ?>">Ubah Profil</a></li>
                            <li><a href="<?= base_url(); ?>">Ubah Password</a></li>
                            <li><a href="<?= base_url('auth/logout'); ?>">Keluar</a></li>
                        </ul>
                    </li>
                    <li><a href="<?= base_url('blog/create'); ?>" style="color:white"><span class="glyphicon glyphicon-plus"></span> Create Post</a></li>
                </ul>
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?= base_url('home'); ?>" style="color:white">CariMakan.com</a>
                    <form class="navbar-form navbar-left" action="Setelah Login/search/index.html" role="search" id="navBarSearchForm">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Cari">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </nav>
    </div>