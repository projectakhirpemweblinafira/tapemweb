<footer class="footer-distributed" width:100%>
    <div class="footer-left">
        <h3>CariMakan.com</h3>
        <p class="footer-company-name">&copy; 2018</p>
    </div>

    <div class="footer-center">

        <div>
            <i class="fa fa-map-marker"></i>
            <p><span>Jl. Soekarno Hatta No. 38</span>Malang, Indonesia</p>
        </div>
        <div>
            <i class="fa fa-phone"></i>
            <p>+62 341 1234567</p>
        </div>
        <div>
            <i class="fa fa-envelope"></i>
            <p><a href="mailto:support@company.com" style="color: white">carimakancom@student.ub.ac.id</a></p>
        </div>

    </div>

    <div class="footer-right">

        <p class="footer-company-about" style="color:white">
            <span><b>About</b></span>
            CariMakan.com merupakan sebuah website responsif yang berisi tentang review tempat yang bertujuan untuk memenuhi tugas Pemrograman Web.
        </p>

        <div class="footer-icons">
            <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
            <a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
            <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
            <a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a>
        </div>
    </div>
</footer>

<script>
    $(document).ready(function() {
        $(".dropdown-toggle").dropdown();
    });
</script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="<?= base_url('assets/') ?>js/index.js"></script>

</body>

</html>